using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Capri")]
[assembly: AssemblyDescription("An unofficial, silent desktop companion")]
[assembly: AssemblyCompany("Capri fan project")]
[assembly: AssemblyProduct("Capri")]
[assembly: AssemblyCopyright("Copyright 2026 Lachy")]
[assembly: AssemblyVersion("0.8.5")]
[assembly: AssemblyFileVersion("0.8.5")]
[assembly: ComVisible(false)]
